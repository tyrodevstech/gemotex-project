from pathlib import Path

DEBUG = True
ROOT = Path.home()
DOMAIN_ROOT = "public_html"
